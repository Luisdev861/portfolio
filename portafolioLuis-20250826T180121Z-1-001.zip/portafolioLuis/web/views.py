from django.shortcuts import render

# Create your views here.

def index(request):
	return render(request, 'index.html')

def quien_soy(request):
	return render(request,'presentacion.html')

def proyectos(request):
	return render(request,'proyectos.html')

def contacto(request):
	return render(request,'contacto.html')
